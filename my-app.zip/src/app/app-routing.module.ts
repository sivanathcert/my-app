import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './logincomponent/logincomponent';
import { RegisterComponent } from './registercomponent/registercomponent';
import { AboutusComponent } from './aboutuscomponent/aboutus.component';
import { ContactusComponent } from './contactuscomponent/contactus.component';
import { HomeComponent } from './homecomponent/home.component';
const routes: Routes = [
  {
    path:'home',
    component: HomeComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'aboutus',
    component: AboutusComponent 
  },
  {
    path: 'contactus',
    component: ContactusComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
