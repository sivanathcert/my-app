import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './registercomponent.html',
  styleUrls: ['./registercomponent.css']
})
export class RegisterComponent {
  
}